#!/bin/bash
export i3=/usr/local/i3
export PATH=$i3:$PATH
cd ~/BasicBoard
eval "jl"
$SHELL