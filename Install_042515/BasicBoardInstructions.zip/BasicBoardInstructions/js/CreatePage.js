// JavaScript Document
function createHTMLFile()
{
	window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem; 
    window.requestFileSystem(window.TEMPORARY, 5*1024*1024, onInitFs)
}
function onInitFs(fs) {
  console.log('Opened file system: ' + fs.name);
}
