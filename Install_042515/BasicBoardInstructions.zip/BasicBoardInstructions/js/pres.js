var currentSlide = 0;

$(function () {
	$(document).keyup(function(e) {
		if(e.keyCode == 39 || e.keyCode == 40 || e.keyCode == 32) next();
		else if(e.keyCode == 37 || e.keyCode == 38 || e.keyCode==8) back();		
	});
	initSlides();
	toggleDiv();	
});
function initSlides(){
	var sections = document.getElementsByTagName("section");
	for (var i=0, item; section = sections[i]; i++) { 
	 section.className = "init";
	}
	goto(currentSlide);
}
var currentDiv = false;
function toggleDiv()
{
 if(currentDiv == false) currentDiv = true;
 else if(currentDiv == true) currentDiv = false; 
  
  showCurrentDiv();
}
function showCurrentDiv()
{
  //if(currentDiv)
  //{
  	showImageDiv();
  //}
  //else
  //{
	//showVideoDiv();
  //}
}
function showVideoDiv()
{
  var section = $('section').eq(currentSlide);
  var visualDiv = section.children()[0].childNodes[3].childNodes[1];
  var imageDiv = visualDiv.childNodes[5];
  var videoDiv = visualDiv.childNodes[3];
  
  imageDiv.className = "hidden";
  videoDiv.className = "active";

}
function showImageDiv()
{
  var section = $('section').eq(currentSlide);
  var visualDiv = section.children()[0].childNodes[3].childNodes[1];
  var imageDiv = visualDiv.childNodes[5];
  var videoDiv = visualDiv.childNodes[3];
  
  imageDiv.className = "active";
  videoDiv.className = "hidden";  
}

function next() {	
	removeLeft(currentSlide);
	goto(currentSlide+1);
	onResize();	
}
function back() {	
	removeRight(currentSlide);
	goto(currentSlide-1);	
	onResize();
}
function goto(n){
	if(n >= 0 && n < $('section').length)
	{
		currentSlide = n;
	}
	else return;
	showCurrentDiv();
	
	var section = $('section').eq(currentSlide);
	if(section.hasClass("right"))
	{
		$('section').eq(currentSlide).removeClass("right").addClass("active");
	}
	if(section.hasClass("init"))
	{
		$('section').eq(currentSlide).removeClass("init").addClass("active");
	}
	if(section.hasClass("left"))
	{
		$('section').eq(currentSlide).removeClass("left").addClass("active");
	}	
}
function removeLeft(n)
{	
	if(n >= 0 && n < $('section').length-1){ }
	else return;	
	
	$('section').eq(currentSlide).removeClass("active").addClass("left");
	
}
function removeRight(n)
{
	if(n >= 1 && n < $('section').length){ }
	else return;	
	
	$('section').eq(currentSlide).removeClass("active").addClass("right");
}
function onResize(event) {
	var height = $(window).height();
	var section = $('section').eq(currentSlide);
	section.children()[0].childNodes[3].style.height = (height-125).toString()+"px"; 	
}