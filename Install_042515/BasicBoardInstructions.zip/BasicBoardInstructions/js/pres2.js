var currentSlide = 0;

$(function () {
	$(document).keyup(function(e) {
		if(e.keyCode == 39 || e.keyCode == 40 || e.keyCode == 32) next();
		else if(e.keyCode == 37 || e.keyCode == 38 || e.keyCode==8) back();		
	});
	initSlides();	
});
function initSlides(){
	var sections = document.getElementsByTagName("section");
	for (var i=0, item; section = sections[i]; i++) { 
	 section.className = 'right';
	}
	goto(currentSlide);
}
var currentDiv = false;

function next(){
	removeLeft(currentSlide);
	goto(currentSlide+1);
}
function back() {
	removeRight(currentSlide);
	goto(currentSlide-1);
}
function goto(n){
	if(n >= 0 && n < $('section').length)
	{
		currentSlide = n;
	}
	else return;
	var section = $('section').eq(currentSlide);
	if(section.hasClass("right"))
	{
		$('section').eq(currentSlide).removeClass("right").addClass("active");
	}
	if(section.hasClass("left"))
	{
		$('section').eq(currentSlide).removeClass("left").addClass("active");
	}
	
}
function removeLeft(n)
{	
	if(n >= 0 && n < $('section').length-1){ }
	else return;	
	
	$('section').eq(currentSlide).removeClass("active").addClass("left");
	
}
function removeRight(n)
{
	if(n >= 1 && n < $('section').length){ }
	else return;	
	
	$('section').eq(currentSlide).removeClass("active").addClass("right");
}