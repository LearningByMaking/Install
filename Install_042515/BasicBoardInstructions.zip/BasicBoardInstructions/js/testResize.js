// JavaScript Document
function onResize(event) {
	var height = $(window).height();
	document.getElementById("contentDiv").style.height = (height-125).toString()+"px"; 	
}