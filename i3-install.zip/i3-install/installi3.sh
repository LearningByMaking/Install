#!/bin/bash
sudo apt-get update
sudo apt-get install openssh-server
sudo apt-get install imagemagick
sudo apt-get install openjdk-6-jre
sudo unzip i3.zip -d /usr/local
sudo find /usr/local/i3/ 
cp .bashrc ~/
sudo cp 77-ulogo.rules /etc/udev/rules.d

sudo rmmod rtl8723be
sudo modprobe rtl8723be

if [ ! -d /home/user/Documents/Scripts ];
then
	mkdir /home/user/Documents/Scripts
fi;
cp DisableTouchpad.sh ~/Documents/Scripts

if [ ! -d ~/.config/autostart ];
then
	mkdir ~/.config/autostart
fi;
cp DisableTouchpad.sh.desktop ~/.config/autostart

cd /usr/local/i3 
find . -exec chmod 775 {} \; 
