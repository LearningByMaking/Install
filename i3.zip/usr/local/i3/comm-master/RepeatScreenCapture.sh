while true
do		
	sh ScreenCapture.sh
	sleep 1
done
