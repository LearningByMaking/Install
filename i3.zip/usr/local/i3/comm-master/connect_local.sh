exec ./RepeatScreenCapture.sh & 
exec ./dtach_local.sh




