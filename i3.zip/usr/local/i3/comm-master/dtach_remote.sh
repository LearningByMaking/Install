#!/bin/bash
ssh -A -t lbym@lbym.sonoma.edu "./Documents/Scripts/ConnectToMeetingByMachineNumber.sh $1"
